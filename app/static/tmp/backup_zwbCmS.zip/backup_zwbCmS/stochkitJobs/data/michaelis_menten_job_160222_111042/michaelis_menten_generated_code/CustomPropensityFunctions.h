#ifndef _CUSTOM_PROPENSITY_FUNCTIONS_H_
#define _CUSTOM_PROPENSITY_FUNCTIONS_H_

#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>

using namespace std;

namespace STOCHKIT
{
template<typename _populationVectorType>
double f2(_populationVectorType& x) {
    return (double)10 * x[1] /(double) (110 + x[1]);
}

template<typename _populationVectorType>
class CustomPropensityFunctions
{
public:
    static const int NumberOfReactions = 3;
    typedef double (*PropensityMember)(_populationVectorType&);
    std::vector<PropensityMember> propensityFunctions;

    // default constructor
    CustomPropensityFunctions() {
        propensityFunctions.resize(3);
        propensityFunctions[2] = &f2<_populationVectorType>;
    }
};
}
#endif
