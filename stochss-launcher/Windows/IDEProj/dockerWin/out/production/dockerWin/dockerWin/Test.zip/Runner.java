package dockerWin;

import java.io.IOException;

public class Runner {

	public static void main(String[] args) {
		UIHandler window = new UIHandler();
		Main main = new Main(window);
		//MainT main = new MainT(window);
		window.setMain(main);
		
		try {
			if (main.checkIfInstalled()) {
				window.setStartup();
			} else {
				window.setStopped();
			}
		} catch (IOException e) {
			main.log(e, true);
		}
	}

}
