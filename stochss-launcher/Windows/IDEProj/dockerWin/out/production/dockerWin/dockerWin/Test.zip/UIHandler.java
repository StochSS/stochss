package dockerWin;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;


public class UIHandler{
	
	public enum State { loading, startup, notInstall, running, stopped; }
	
	State state;
	private final int width = 500;
	private final int height = 300;
	private final int buttonWidth = 200;
	private final int buttonHeight = 50;
	private JButton stochSSButton, webButton, settingsButton;
	private String title = "StochSS Launcher";
	private Main m;
	private JFrame frame, settings;


    public UIHandler() {
    	state = State.loading;
    	frame = new JFrame(title);
        Dimension size = new Dimension(width, height);
        frame.setPreferredSize(size);
        frame.setMaximumSize(size);
        frame.setMinimumSize(size);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
        frame.getContentPane().setLayout(null);
        
        stochSSButton = new JButton("Loading...");
        stochSSButton.setBounds(150, 200, buttonWidth, buttonHeight);
        stochSSButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stochSSButtonPressed();
				} catch (IOException e1) {
					m.log(e1, true);
				}
			}
        });
        
        webButton = new JButton("Launch StochSS");
        webButton.setBounds(265, 200, buttonWidth, buttonHeight);
        webButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				webButtonPressed();
			}
        });
        
        settingsButton = new JButton("Settings");
        settingsButton.setBounds(425, 20, buttonHeight, buttonHeight);
        settingsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				settingsButtonPressed();
			}
        });
        
        frame.addWindowListener(new WindowAdapter() {
        	@Override
            public void windowClosing(WindowEvent e) {
        		if (state != State.stopped) {
            		try {
            			m.safeExit();
            		} catch (IOException e1) {
            			m.log(e1, true);
            		}
            		dispose();
            	} else {
            		System.exit(0);
            	}
            }
        });
        
        frame.add(stochSSButton);
        frame.add(settingsButton);
    }
    
    private void settingsButtonPressed() {
    	setSettings();
    }
    

    private void showLaunchButton() {
    	stochSSButton.setBounds(35, 200, buttonWidth, buttonHeight);
    	frame.add(webButton);
    	frame.revalidate();  
    	frame.repaint();
    }
    
    private void hideLaunchButton() {
    	stochSSButton.setBounds(150, 200, buttonWidth, buttonHeight);
    	webButton.setVisible(false);
    	frame.revalidate();
    	frame.repaint();
    }
    
    private void stochSSButtonPressed() throws IOException {
    	switch (state) {
    	case loading: 
    					break;
    	case startup: 	
    					setLoading(); //TODO what the fuck setLoading is useless right now
    					m.startStochSS(); 
    					setRunning();
    					showLaunchButton();
    					break;
    	case notInstall: 
    					setLoading();
    					m.installContainer(); 
    					setStartup();
    					break;
    	case running: 
    					setLoading();
    					m.safeExit();
    					setStopped();
    					hideLaunchButton();
    					break;
    	case stopped: 
    					System.exit(0); 
    					break;
    	default:		
    	}
    }
    
    private void webButtonPressed() {
    	if (state == State.running) {
    		if (!m.openURL()) {
    			System.out.println("There was a problem opening the URL. Please paste " 
    									+ m.getURL() + " into your preferred browser.");
    		}
    	}
    }
    
    public void setLoading() {
    	state = State.loading;
    	stochSSButton.setText("Loading...");
    }
    
    public void setStartup() {
    	state = State.startup;
    	stochSSButton.setText("Start StochSS");
    	
    }
    
    public void setnotInstall() {
    	state = State.notInstall;
    	stochSSButton.setText("Install StochSS");
    }
    
    public void setRunning() {
    	state = State.running;
    	stochSSButton.setText("Stop StochSS");
    }
    
    public void setStopped() {
    	state = State.stopped;
    	stochSSButton.setText("Close Window");
    }
    
    private void setSettings() {
    	settings = new JFrame(title);
        Dimension size = new Dimension(width, height);
        settings.setPreferredSize(size);
        settings.setMaximumSize(size);
        settings.setMinimumSize(size);
        settings.setResizable(false);
        settings.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        settings.setLocationByPlatform(true);
        settings.setVisible(true);
        settings.getContentPane().setLayout(null);
        
        //TODO better
        
    	
    }

    public void setMain(Main ma) {
    	m = ma;
    }

	public void dispose() {
		frame.dispose();
	}
}