package dockerWin;

import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		
		MainT main = new MainT(new UIHandler());
		main.openDockerTerminal(main.getStdin(), main.getStdout());

	}

}
