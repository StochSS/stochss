package dockerWin;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;

public class MainT {
	
	String ip = "0.0.0.0";
	static final String containerName = "stochsscontainer1_9";
	static final String VMName = "stochss1-9";
	String url;
	
	static final String commands[] = {
	/*0*/ "docker ps -a -f name=" + containerName, 													//search for container of container name
	/*1*/ "docker run -i -t -p 9999:9999 -p 8080:8080 --name=" + containerName + " stochss/stochss-launcher:1.9", //pull and create container 																
	/*2*/ "docker start " + containerName,																					//start container
	/*3*/ "docker exec -i " + containerName + " /bin/bash -c \"cd stochss-master && ./run.ubuntu.sh -a 0.0.0.0 -t secretkey\"", //run StochSS
	/*4*/ "docker stop " + containerName,																					//stop container
	/*5*/ "echo jazzhands",
	/*6*/ "docker rm " + containerName,
	/*7*/ "docker rmi stochss/stochss-launcher:1.9",
	/*8*/ "docker-machine rm " + VMName,
	/*9*/ 
	/*10*/
	};
	
	ProcessBuilder builder;
	Process process;
	BufferedWriter stdin;
	BufferedReader stdout;
	UIHandler window;
	Process exit;
	
	public MainT(UIHandler w) {
		window = w;
		builder = new ProcessBuilder("cmd");
		try { 
			process = builder.start();
		} catch (IOException e) {
			log(e, true);
		}
	    stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
	    stdout = new BufferedReader(new InputStreamReader(process.getInputStream()));
	}
	
	public BufferedWriter getStdin() { return stdin; }
	public BufferedReader getStdout() { return stdout; }
	
	public boolean openDockerTerminal(BufferedWriter in, BufferedReader out) throws IOException {
		String piece1 = "\\bin\\bash.exe\" --login -i \"";
		String piece2 = "start.sh\"";
		//when assembled, should look like this:
		//"C:\Program Files\Git\bin\bash.exe" --login -i "C:\Program Files\Docker Toolbox\start.sh"
		in.write("where docker");
		in.newLine();
		in.write("where git");
		in.newLine();
		in.write(commands[5]);
		in.newLine();
		in.flush();
		String line, path = "", path2 = "";
		while((line = stdout.readLine()) != null && !line.contains(commands[5])) { 
	    	System.out.println(line);
	    	if(line.contains("Docker Toolbox")) {
	    		path = line.substring(0,  line.indexOf("docker.exe"));
	    	}
	    	if(line.contains("git.exe")) {
	    		path2 = "\"" + line.substring(0, line.indexOf("\\cmd\\git.exe"));
	    	}
		}
		if (!(path.isEmpty() || path2.isEmpty())) {
			System.out.println(path2 + piece1 + path + piece2);
		} else {
			return false;
		}
		return true; //TODO
	}
	
	public boolean uninstall() throws IOException {
		String line;
		stdin.write(commands[6]); //TODO make sure completed
		stdin.newLine();
		stdin.write(commands[7]);
		stdin.newLine();
		stdin.write(commands[8]);
		stdin.newLine();
		stdin.write(commands[5]);
		stdin.newLine();
		stdin.flush();
		while((line = stdout.readLine()) != null && !line.contains(commands[5])) { 
	    	System.out.println(line);
		}
		return true;
	}
	
	public boolean checkIfInstalled() throws IOException {
		String line;
	    stdin.write(commands[0]); 
	    stdin.newLine();
	    stdin.write(commands[5]); 
	    stdin.newLine();
	    stdin.flush();
	    
	    while((line = stdout.readLine()) != null && !line.contains(commands[5])) { 
	    	System.out.println(line);
	    	if (line.contains(containerName)) {
	    		window.setStartup();
	    		return true;
	    	}
	    	if (line.contains("random-ass error message I haven't identified yet")) {
	    		process.destroy();
	    		window.setStopped();
	    		return false;
	    	}
	    }
	    return false;
	}
	    
	public boolean startStochSS() throws IOException {
		String line;
	    stdin.write(commands[2]);
	    stdin.newLine();
	    stdin.write(commands[3]);
	    stdin.newLine();
	    stdin.write(commands[5]);
	    stdin.newLine();
	    stdin.flush();
	    while((line = stdout.readLine()) != null && !line.startsWith("Navigate to ") && !line.contains(commands[5])) { 
	    	System.out.println(line);
		}
	    try {
	    	url = line.substring(12, line.indexOf(" to access StochSS"));
	    	if(url.contains("0.0.0.0")) {
	    		int temp = url.indexOf("0.0.0.0");
	    		url = url.substring(0, temp) + "127.0.0.1" + url.substring(temp + 7);
	    	}
	    	System.out.println("Navigate to " + url + " to access StochSS");
	    	return true;
	    } catch (Exception e) {
	    	log(e, true);
	    	return false;
	    }
	}
	    
	public boolean openURL() {
		if (Desktop.isDesktopSupported()) {
	    	try {
				Desktop.getDesktop().browse(new URI(url));
				return true;
			} catch (URISyntaxException | IOException e) {
				log(e, false);
				return false;
			}
		}
		return false;
	}
		
	public void installContainer() throws IOException {
		String line;
		stdin.write(commands[1]);
		stdin.newLine();
		stdin.write(commands[5]);
		stdin.newLine();
		while((line = stdout.readLine()) != null && !line.contains(commands[5])) { 
			System.out.println(line); //TODO
		}
	}
	
	public void safeExit() throws IOException {
		exit = builder.start();	
		BufferedWriter exitin = new BufferedWriter(new OutputStreamWriter(exit.getOutputStream()));
	    BufferedReader exitout = new BufferedReader(new InputStreamReader(exit.getInputStream()));
	    String line;
	    exitin.write(commands[4]);
	    exitin.newLine();
	    exitin.write(commands[5]);
	    exitin.newLine();
	    exitin.flush();
	    while((line = exitout.readLine()) != null && !line.contains(commands[5])) { 
			System.out.println(line); 
		}
		destroyProcesses();
	}
	
	private void destroyProcesses() {
		process.destroy();
		exit.destroy();
	}
	
	public void log(Exception e, boolean exit) {
		String s = "";
		if(exit) {
			try {
				safeExit();
			} catch (Exception ex) {
				s ="Safe exit failed.\n";
				destroyProcesses();
			} finally {
				window.setStopped();
			}
		}
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		s += errors.toString(); //TODO something with this
	}

	public String getURL() {
		return url;
	}

}